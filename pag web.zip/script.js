Document.querySelector('h1').addEventListener('click', () => {
    document.body.style.background = 'green';
})